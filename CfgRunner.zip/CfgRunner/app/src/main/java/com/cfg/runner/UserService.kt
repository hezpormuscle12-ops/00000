package com.cfg.runner

import kotlin.system.exitProcess

/** Chạy trong tiến trình quyền shell do Shizuku tạo ra. */
class UserService : IUserService.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun exec(cmd: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            "$code\n$out"
        } catch (e: Exception) {
            "-1\n${e.message}"
        }
    }
}
