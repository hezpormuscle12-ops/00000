package com.cfg.runner

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import kotlin.math.max

/** Video chạy lặp, tắt tiếng, phủ kín nền (cắt giữa như centerCrop). */
class VideoBg(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private var vw = 0
    private var vh = 0
    private var surface: Surface? = null

    init { surfaceTextureListener = this }

    private fun start() {
        val s = surface ?: return
        release()
        try {
            val afd = resources.openRawResourceFd(R.raw.bg)
            mp = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setSurface(s)
                isLooping = true
                setVolume(0f, 0f)
                setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; crop() }
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) {}
    }

    private fun crop() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val sx = width.toFloat() / vw
        val sy = height.toFloat() / vh
        val s = max(sx, sy)
        val m = Matrix()
        m.setScale(s / sx, s / sy, width / 2f, height / 2f)
        setTransform(m)
    }

    fun pause() { try { mp?.pause() } catch (_: Exception) {} }
    fun resume() { try { mp?.start() } catch (_: Exception) {} }
    fun release() { try { mp?.release() } catch (_: Exception) {}; mp = null }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { surface = Surface(st); start() }
    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { crop() }
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); surface?.release(); surface = null; return true }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}
