package com.cfg.runner

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** Gói gọn Shizuku: kiểm tra, xin quyền, chạy lệnh shell. */
object Sh {
    @Volatile var svc: IUserService? = null
    private var binding = false

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request(code: Int) { try { Shizuku.requestPermission(code) } catch (_: Throwable) {} }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = if (binder != null && binder.pingBinder()) IUserService.Stub.asInterface(binder) else null
            binding = false
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null; binding = false }
    }

    fun bind(ctx: Context) {
        if (svc != null || binding || !granted()) return
        try {
            binding = true
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
                .daemon(false).processNameSuffix("svc").debuggable(false).version(2)
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) { binding = false }
    }

    /** Trả về (mã thoát, đầu ra) hoặc null nếu chưa có dịch vụ shell. */
    fun exec(cmd: String): Pair<Int, String>? {
        val s = svc ?: return null
        return try {
            val r = s.exec(cmd)
            val i = r.indexOf('\n')
            val code = r.substring(0, if (i < 0) r.length else i).trim().toIntOrNull() ?: -1
            code to (if (i < 0) "" else r.substring(i + 1).trim())
        } catch (e: Throwable) { -1 to (e.message ?: "lỗi") }
    }

    fun ready() = svc != null
}
