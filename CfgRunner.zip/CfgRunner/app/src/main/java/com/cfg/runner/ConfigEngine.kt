package com.cfg.runner

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

object ConfigEngine {
    private const val SECURE = "android.permission.WRITE_SECURE_SETTINGS"

    fun hasSecure(ctx: Context) =
        ctx.checkSelfPermission(SECURE) == PackageManager.PERMISSION_GRANTED

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun get(ctx: Context, ns: String, k: String): String? = try {
        when (ns) {
            "global" -> Settings.Global.getString(ctx.contentResolver, k)
            "secure" -> Settings.Secure.getString(ctx.contentResolver, k)
            else -> Settings.System.getString(ctx.contentResolver, k)
        }
    } catch (e: Exception) { null }

    private fun putApi(ctx: Context, ns: String, k: String, v: String?): Boolean {
        val cr = ctx.contentResolver
        return when (ns) {
            "global" -> Settings.Global.putString(cr, k, v)
            "secure" -> Settings.Secure.putString(cr, k, v)
            else -> Settings.System.putString(cr, k, v)
        }
    }

    /** Ghi 1 giá trị: ưu tiên API (nhanh), không có quyền thì dùng shell qua Shizuku. */
    private fun put(ctx: Context, ns: String, k: String, v: String?): String? {
        if (hasSecure(ctx)) {
            return try { if (putApi(ctx, ns, k, v)) null else "hệ thống từ chối" } catch (e: Exception) { e.message }
        }
        val cmd = if (v == null) "settings delete $ns ${q(k)}" else "settings put $ns ${q(k)} ${q(v)}"
        val r = Sh.exec(cmd) ?: return "chưa có quyền (cần Shizuku hoặc cấp WRITE_SECURE_SETTINGS)"
        return if (r.first == 0) null else "exit ${r.first}: ${r.second}"
    }

    data class Result(val log: String, val ok: Int, val fail: Int)

    fun apply(ctx: Context, text: String, record: Boolean = true): Result {
        val sb = StringBuilder()
        val undo = JSONArray()
        var section: String? = null
        var ok = 0; var fail = 0

        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith(";")) continue
            if (line.startsWith("[") && line.endsWith("]")) {
                section = line.substring(1, line.length - 1).trim().lowercase()
                sb.append("[$section]\n"); continue
            }
            when (section) {
                "global", "system", "secure" -> {
                    val i = line.indexOf('=')
                    if (i <= 0) { sb.append("  ⚠ bỏ qua: $line\n"); fail++; continue }
                    val k = line.substring(0, i).trim()
                    var v: String? = line.substring(i + 1).trim()
                    if (v == "-") v = null
                    val old = get(ctx, section, k)
                    val err = put(ctx, section, k, v)
                    if (err == null) {
                        undo.put(JSONObject().put("ns", section).put("k", k).put("old", old ?: JSONObject.NULL))
                        sb.append("  ✔ $k: ${old ?: "∅"} → ${get(ctx, section, k) ?: "∅"}\n"); ok++
                    } else { sb.append("  ✘ $k: $err\n"); fail++ }
                }
                "shell" -> {
                    val r = Sh.exec(line)
                    if (r == null) { sb.append("  ✘ cần Shizuku: $line\n"); fail++ }
                    else if (r.first == 0) { sb.append("  ✔ $line\n"); if (r.second.isNotEmpty()) sb.append("    ${r.second.take(300)}\n"); ok++ }
                    else { sb.append("  ✘ $line → exit ${r.first} ${r.second.take(200)}\n"); fail++ }
                }
                "stop" -> {
                    val r = Sh.exec("am force-stop ${q(line)}")
                    if (r == null) { sb.append("  ✘ cần Shizuku: dừng $line\n"); fail++ }
                    else if (r.first == 0) { sb.append("  ✔ đã dừng $line\n"); ok++ }
                    else { sb.append("  ✘ $line: ${r.second.take(200)}\n"); fail++ }
                }
                else -> { sb.append("  ⚠ dòng nằm ngoài section hợp lệ: $line\n"); fail++ }
            }
        }
        if (record && undo.length() > 0) {
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("undo", undo.toString()).apply()
        }
        sb.append("\nXong: $ok thành công, $fail lỗi.")
        return Result(sb.toString(), ok, fail)
    }

    fun hasUndo(ctx: Context) =
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("undo", null) != null

    fun undo(ctx: Context): String {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val js = p.getString("undo", null) ?: return "Chưa có gì để hoàn tác."
        val arr = JSONArray(js)
        val sb = StringBuilder("Hoàn tác lần chạy trước:\n")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            val old = if (o.isNull("old")) null else o.getString("old")
            val err = put(ctx, o.getString("ns"), o.getString("k"), old)
            sb.append(if (err == null) "  ↩ ${o.getString("k")} = ${old ?: "∅"}\n" else "  ✘ ${o.getString("k")}: $err\n")
        }
        p.edit().remove("undo").apply()
        return sb.toString()
    }
}
